/*
<Link V Ganon RPG>
Arhdeep Shienh
21036062

INSTRUCTIONS
Click on any button you'd like. mousePressed is the only event function needed as keyPressed would
be redundant in a RPG fighting game. Fight Ganon and try to chip his HP away to 0 before he's able
to kill Link !


CODING QUALITY AND VISUAL DESIGN
The visuals of this game are immaculate. We tried to use as many images and sounds we can to make it
look like an actual game you'd see on, for example the Nintendo Switch. The code works flawless as they're
no gamebreaking bugs, as well as we figured out a way to create animations using timers. I think the coolest
part of our game is that I made it very RNG based, its random on who attacks first, random if Link dodges, random
on the amount of damage the characters do, even the run feature has a random chance of failing !

VIDEO
https://www.kapwing.com/videos/638eb8fd0a9171001e989da9

RELEASE
I, Arshdeep Shienh grant permission to CS 105 course staff to use
my Final Project program and video for the purpose of promoting CS 105.
*/

// Variable initialization
let WIDTH = 600;
let HEIGHT = 600;
s3buttonX = [120, 300, 480];
screen = [false, false, true]; // S[0] = stats , S[1] = fight, S[2] = main
attackScreen = [false, false];
ganonText = ["You'll Regret this Boy!", "Run While You Can!", "You Won't Survive", "You're NO Hero of Time"];
s1buttonX = [WIDTH / 4, (WIDTH / 4) * 3];
fled = false;
radiusMAINSCREEN = 100;
radiusFIGHTSCREEN = 150;
radiusSTATSSCREEN = 50;
let LinkHP = 100;
let LinkHPGauge;
let GanonHP = 200;
let GanonHPGauge;
let GanonStatHP;
let linkcounter = 0;
let ganoncounter = 0;
let rndChance;
let rndTextValue;
let escapetimer = 0;
let textSelection;
let rndAttack;
let linkDodgeRND;
let GanonAttackRND;
let attackFirstRND;
let gameRun = true;
let gameRunTimer = 0;

// Preloading character sprites and sound effects
function preload() {
	linkCloseUp = loadImage("linkcloseup.png");
	linkSit = loadImage("linksitting.png");
	linkStand = loadImage("linkstanding2.png");
	ganonStand = loadImage("ganonstand.png");
	ganonCloseUp = loadImage("ganoncloseup.png");
	linkJump = loadImage("linkjump.png");
	linkSwipe = loadImage("linkswipe.png");
	ganonAttack = loadImage("ganonattack.png");
	linkDodge = loadImage("linkdodgealt.png");
	linkHurt = loadImage("linkhurtalt.png");
	linkSpinAttack1 = loadImage("linkspinattack1alt.png");
	linkSpinAttack2 = loadImage("linkspinattack2alt.png");
	phantomGanon = loadImage("phantomganon.png");
	defeatscreen = loadImage("defeat.png");
	victoryscreen = loadImage("victoryscreen.png");
	thunder = loadImage("thunder.png");
	musicmez = loadSound("musicmez.wav");
	linkswipe = loadSound("linkswordswipealt.wav");
	linkspinattack = loadSound("linkspinattackalt.wav");
	phantomganonaudio = loadSound("phantomganonalt.wav");
	linkdodge = loadSound("linkdodgealt.wav");
	linkhurt = loadSound("linkhurtalt.wav");
	soundFormats('wav');
}

// Static variables
function setup() {
	musicmez.loop();
	createCanvas(WIDTH, HEIGHT);
	background("#87CEEB");
	frameRate(10);
	rndChance = random(0, 2);
}
// Screen status check
function draw() {
if (gameRun === true) {
		if (LinkHP < 50) {
		rndChance = 0.5;
	} if (screen[2] === true) {
		mainscreen();
	} else if (screen[1] === true) {
		fightscreen();
	} else if (screen[0] === true) {
		statsscreen();
	} else if (attackScreen[0] === true) {
		swordSwipe();
	} else if (attackScreen[1] === true) {
		spinAttack();
	} 
	
	if (screen[0] === false) {
		HUD();
	}
	
if (fled === true) {
	if (rndChance > 1) {
	fledscreen();
	} else {
		failureScreen();
	}
	}
}  // If Link's HP falls below 0, defeat 
		if (LinkHP < 0 || LinkHP === 0) {
		gameRunTimer++;
			
		if (gameRunTimer === 8) {
		gameRun = false;
		defeat()
		}
	} // If Ganon's HP falls below 0, victory 
	if (GanonHP < 0 || GanonHP === 0) {
		gameRunTimer++;
			
		if (gameRunTimer === 8) {
		gameRun = false;
		victory();
		}
	}
}

// Main menu buttons 
function buttons(x, y) {
	
	strokeWeight(5);
	fill(200);
	circle(x, y, radiusMAINSCREEN);

}
// Button pressed 
function mousePressed() {
// Main menu
if (screen[2] === true) {
	i = getIndex2(mouseX, mouseY);
	
}
// Fight screen
if (screen[1] === true) {
	i = getIndex1(mouseX, mouseY);
	
}
//  Stat screen 
if (screen[0] === true) {
	i = getIndex0(mouseX, mouseY);
}
}

// Button status 

// Stat screen initialization 
function getIndex0(x, y) {
	if (screen[0] === true) {
	let d = dist(x, y, width - 40, 40);
	if (d < radiusSTATSSCREEN / 2) {
		screen[0] = false;
		screen[2] = true;
		return i;
	}
	}
}

// Fight screen initialization 
function getIndex1(x, y) {
if (screen[1] === true) {
	for (i = 0; i < s1buttonX.length; i++) {
	let d = dist(x, y, 0 + s1buttonX[i], height / 1.34);
	 if (d < radiusFIGHTSCREEN / 2) {
	  attackScreen[i] = true;
		linkDodgeRND = random(0, 4);
	  attackFirstRND = random(0, 4);
		GanonAttackRND = random(0, 4);
		screen[1] = false;
		return i;
	 }
	}
	}
}

// Main screen initialization 
function getIndex2(x, y) {
if (screen[2] === true) {
	let d2 = dist(x, y, 0 + s3buttonX[2], height / 1.35);
	 if (d2 < radiusMAINSCREEN / 2) {
	 fled = true;
	 }
	
	for (i = 0; i < 2; i++) {
	let d3 = dist(x, y, 0 + s3buttonX[i], height / 1.35);
		if (d3 < radiusMAINSCREEN / 2) {
			screen[i] = true;
			screen[2] = false;
			return i;
		}
	}
	}
}
// Main screen
function mainscreen() {
	
if (screen[2] === true) {
	backgroundTemplate();

	//button function call
	buttons(s3buttonX[0], height / 1.35);
	buttons(s3buttonX[1], height / 1.35);
	buttons(s3buttonX[2], height / 1.35);
	
//Button text
	fill(0);
	strokeWeight(1);
	textSize(25);
	text("FIGHT", 261, height / 1.33);
	text("STATS", 80, height / 1.33);
	text("RUN", 453, height / 1.33);
	
	// Link character sprite dimensions 
	linkStandWIDTH = linkStand.width * 0.15
	linkStandAR = linkStand.width / linkStand.height
	linkStandHEIGHT = linkStandWIDTH * linkStandAR
	
	// Ganon character sprite dimensions 
	ganonStandWIDTH = ganonStand.width * 0.10
	ganonStandAR = ganonStand.width / ganonStand.height
	ganonStandHEIGHT = ganonStandWIDTH * ganonStandAR

	// Sprite shadow 
	noStroke();
	fill(0, 0, 0, 125);
	ellipse(80, height / 2 + 25, 90, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link & Ganon initialization 
	image(linkStand, 40, height / 3, linkStandWIDTH, linkStandHEIGHT);
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	
}
}

// Fight screen 
function fightscreen() {
	// Screen status scheck
	screen[0] = false;
	screen[2] = false;
	// Background 
	backgroundTemplate();
		// Fight buttons function call
	fill(200);
	strokeWeight(5);
	ellipse(s1buttonX[0], height / 1.34, radiusFIGHTSCREEN);
	ellipse(s1buttonX[1], height / 1.34, radiusFIGHTSCREEN);
	
	// Fight button text
	fill(0);
	strokeWeight(1);
	textSize(30)
	text("Sword", s1buttonX[0] - 40, height / 1.35);
	text("Swipe", s1buttonX[0] - 40, height / 1.25);
	
	text("Spin", s1buttonX[1] - 30, height / 1.35);
	text("Attack", s1buttonX[1] - 40, height / 1.25);

	// Sprite shadows
	noStroke();
	fill(0, 0, 0, 125);
	ellipse(80, height / 2 + 25, 90, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link & Ganon sprite initialization 
	image(linkStand, 40, height / 3, linkStandWIDTH, linkStandHEIGHT);
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);

}
// Stat screen 
function statsscreen() {
	stroke(0);
	strokeWeight(10);
	background(200);
	fill(80);
	rect(40, 40, width - 80, height - 80);
	fill(0);
	line(width / 2, 40, width / 2, height - 40);
	line(40, height - 240, height - 40, height - 240);
	
	// Link character icon dimensions
	linkCloseUpWIDTH = linkCloseUp.width * 0.3
	linkCloseUpAR = linkCloseUp.width / linkCloseUp.height
	linkCloseUpHEIGHT = linkCloseUpWIDTH * linkCloseUpAR
	
	// Ganon character icon dimensions
	ganonCloseUpWIDTH = ganonCloseUp.width * 0.8
	ganonCloseUpAR = ganonCloseUp.width / ganonCloseUp.height
	ganonCloseUpHEIGHT = ganonCloseUpWIDTH * ganonCloseUpAR
	
	// Link character icon initialization 
	image(ganonCloseUp, 440, 50, ganonCloseUpWIDTH, ganonCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(440, 50, 115, 115);
	
	// Ganon character icon initialization 
	image(linkCloseUp, 50, 50, linkCloseUpWIDTH, linkCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(50, 50, 115, 116);
	
	// Link HP gauge box 
	strokeWeight(2);
	fill(LinkHPGauge);
	rect(48, 175, 100, 30);
	
	// Link stat box colours 
	fill("GREEN");
	rect(48, 210, 170, 30);
	
	fill("RED");
	rect(48, 245, 110, 30);
	
	fill("RED");
	rect(48, 280, 230, 30);
	
	fill("YELLOW");
	rect(48, 315, 170, 30);

	// Link stat text 
	strokeWeight(1);
	fill(0);
	text("Link", 175, 80);
	text("HP : ", 50, 200);
	text(LinkHP, 100, 200);
	text("ATK DMG : 28", 50, 235);
	text("DEF : 15", 50, 270);
	text("SPC ATK DMG : 14", 50, 305);
	text("SPC DEF : 22", 50, 340);
	text("MOVES : ", 50, height - 200);
	text("Sword Swipe", 50, height - 170);
	text("Spin Attack", 50, height - 140);
	
	// Ganon HP gauge box
	fill(GanonHPGauge);
	rect(433, 175, 123, 30);
	
	// Ganon stat box colours 
	fill("RED");
	rect(385, 210, 170, 30);
	
	fill("YELLOW");
	rect(440, 245, 115, 30);
	
	fill("GREEN");
	rect(325, 280, 230, 30);
	
	fill("RED");
	rect(385, 315, 170, 30);
	
	// Ganon stat text 
	fill(0);
	text("Ganon", 355, 80);
	text("HP : ", 440, 200);
	text(GanonHP, 490, 200);
	text("ATK DMG : 19", 390, 235);
	text("DEF : 22", 450, 270);
	text("SPC ATK DMG : 26", 330, 305);
	text("SPC DEF : 14", 390, 340);
	text("MOVES : ", 440, height - 200);
	text("Drop Attack", 415, height - 170);
	text("Phantom Ganon", 365, height - 140);
	
	// Exit button 
	strokeWeight(5);
	fill("RED");
	ellipse(width - 40, 40, radiusSTATSSCREEN);
	line(width - 55, 20, width - 25, 60);
	line(width - 25, 20, width - 55, 60);
	
}

// Fled screen 
function fledscreen() {
	musicmez.stop();
	for (i = 0; i < screen.length; i++) {
		screen[i] = false;
	}
	background(0);
	// Fled the battle text
	fill("RED");
	text("FLED THE BATTLE", width / 2 - 142, height / 2 + 2);
	fill(250);
	text("FLED THE BATTLE", width / 2 - 140, height / 2);
	
	// Link sitting character sprite dimensions 
	linkSitWIDTH = linkSit.width * 0.2
	linkSitAR = linkSit.width / linkSit.height
	linkSitHEIGHT = linkSitWIDTH * linkSitAR
	
	// Link sitting character sprite initialization 
	image(linkSit, width / 1.35, height / 1.4 , linkSitWIDTH, linkSitHEIGHT);

}

// Background initialization 
function backgroundTemplate() {
	
	background("#0c1445");
	noStroke();
	fill("#567d46");
	rect(0, height / 2, width, height / 2);
	
	stroke(0);
	strokeWeight(10);
	fill("BROWN");
	rect(25, height - 225, width - 50, 150);
	
	
}

// Link sword swipe animation and attack probability 
function swordSwipe() {	
	rndTextValue = floor(random(0, 4));
	attackRnd = floor(random(15, 23));	
	if (attackFirstRND < 3) {
		linkcounter++;
	
	if (linkcounter === 3) {
		swordSwipeANI1();
	}
	if (linkcounter === 8) {
		swordSwipeANI2();
	}
	if (linkcounter === 12) {
		swordSwipeANI3();
		
	}
	if (linkcounter === 20) {
		ganonAttack1();
	}
	if (linkcounter === 30) {
		ganonAttack2();
	}
	if (linkcounter === 38) {
		linkcounter = 0;
		attackScreen[0] = false;
		screen[2] = true;
	}
	}

	// Ganon attack animation & attack probability 
	if (attackFirstRND > 3) {
			ganoncounter++;

		if (ganoncounter === 3) {
			ganonAttack1();
		}
		if (ganoncounter === 13) {
			ganonAttack2();
		}
		if (ganoncounter === 23) {
			staticAttackScreen();
		}
		if (ganoncounter === 29) {
			swordSwipeANI1();
		}
		if (ganoncounter === 34) {
			swordSwipeANI2();
		}
		if (ganoncounter === 38) {
			swordSwipeANI3();
		}
		if (ganoncounter === 43) {
		ganoncounter = 0;
		attackScreen[0] = false;
		screen[2] = true;
		}
	}
}

// Link spin attack
function spinAttack() {
	
	rndTextValue = floor(random(0, 4));
	attackRnd = floor(random(15, 23));	
	
	if (attackFirstRND > 3) {
		linkcounter++;
		if (linkcounter === 4) {
			spinAttack1();
				GanonHP = GanonHP - attackRnd / 3;
			GanonStatHP = GanonStatHP - attackRnd / 3;
		}
		if (linkcounter === 6) {
			spinAttack2();
				GanonHP = GanonHP - attackRnd / 3;
			GanonStatHP = GanonStatHP - attackRnd / 3;
		}
		if (linkcounter === 8) {
			spinAttack1();
				GanonHP = GanonHP - attackRnd / 3;
			GanonStatHP = GanonStatHP - attackRnd / 3;
		}
		if (linkcounter === 10) {
			spinAttack2();
				GanonHP = GanonHP - attackRnd / 3;
			GanonStatHP = GanonStatHP - attackRnd / 3;
		}
		if (linkcounter === 12) {
			spinAttack1();
			GanonHP = GanonHP - attackRnd / 3;
			GanonStatHP = GanonStatHP - attackRnd / 3;
		}
		if (linkcounter === 16) {
			staticAttackScreen();
		}
		if (linkcounter === 22) {
			ganonAttack1();
		}
		if (linkcounter === 32) {
			ganonAttack2();
		}
		if (linkcounter === 42) {
			linkcounter = 0;
			attackScreen[1] = false;
			screen[2] = true;
		}
	}
		
		if (attackFirstRND < 3) {
			ganoncounter++;

		if (ganoncounter === 3) {
			ganonAttack1();
		}
		if (ganoncounter === 13) {
			ganonAttack2();
		}
		if (ganoncounter === 23) {
			staticAttackScreen();
		}
		if (ganoncounter === 28) {
			spinAttack1();
				GanonHP = GanonHP - attackRnd / 3 - 1;
			GanonStatHP = GanonStatHP - attackRnd / 3 - 1;
		}
		if (ganoncounter === 30) {
			spinAttack2();
				GanonHP = GanonHP - attackRnd / 3 - 1;
			GanonStatHP = GanonStatHP - attackRnd / 3 - 1;
		}
		if (ganoncounter === 32) {
			spinAttack1();
				GanonHP = GanonHP - attackRnd / 3 - 1;
			GanonStatHP = GanonStatHP - attackRnd / 3 - 1;
		}
		if (ganoncounter === 34) {
			spinAttack2();
				GanonHP = GanonHP - attackRnd / 3 - 1;
			GanonStatHP = GanonStatHP - attackRnd / 3 - 1;
		}
		if (ganoncounter === 36) {
			spinAttack1();
			GanonHP = GanonHP - attackRnd / 3 - 1;
			GanonStatHP = GanonStatHP - attackRnd / 3 - 1;
		}
		if (ganoncounter === 40) {
			attackScreen[1] = false;
			screen[2] = true;
			ganoncounter = 0;
		}
	}
}
// Link spin attack animation 1 
function spinAttack1() {
	
	backgroundTemplate();
	linkspinattack.play();
	
	// Link dialogue 
	strokeWeight(5);
	textSize(35);
	fill(255);
	text("HIYAH!", 60, height - 160);
	
	// Link icon dimensions 
	linkCloseUpWIDTH = linkCloseUp.width * 0.35
	linkCloseUpAR = linkCloseUp.width / linkCloseUp.height
	linkCloseUpHEIGHT = linkCloseUpWIDTH * linkCloseUpAR
		
	// Link icon initialization 
	image(linkCloseUp, 430, 380, linkCloseUpWIDTH, linkCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(430, 380, 135, 140);
	
	// Link spin sprite dimensions 
	linkSpin1WIDTH = linkSpinAttack1.width * 0.18
	linkSpin1AR = linkSpinAttack1.width / linkSpinAttack1.height
	linkSpin1HEIGHT = linkSpin1WIDTH * linkSpin1AR
	
	// Sprite shadows 
	fill(0, 0, 0, 125);
	noStroke();
	ellipse(290, height / 2 + 40, 180, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link spin attack & Ganon standing sprite initialization 
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	image(linkSpinAttack1, 180, 230, linkSpin1HEIGHT, linkSpin1WIDTH);
}
// Link spin attack animation 2 
function spinAttack2() {
	
	backgroundTemplate();
	linkspinattack.play();
	// Link dialogue 
	strokeWeight(5);
	textSize(35);
	fill(255);
	text("HIYAH!", 60, height - 160);
	
	// Link icon dimensions 
	linkCloseUpWIDTH = linkCloseUp.width * 0.35
	linkCloseUpAR = linkCloseUp.width / linkCloseUp.height
	linkCloseUpHEIGHT = linkCloseUpWIDTH * linkCloseUpAR
		
	// Link icon initialization 
	image(linkCloseUp, 430, 380, linkCloseUpWIDTH, linkCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(430, 380, 135, 140);
	
	// Link spin sprite dimensions 
	linkSpin2WIDTH = linkSpinAttack2.width * 0.18
	linkSpin2AR = linkSpinAttack2.width / linkSpinAttack2.height
	linkSpin2HEIGHT = linkSpin2WIDTH * linkSpin2AR
	
	// Sprite shadows  
	fill(0, 0, 0, 125);
	noStroke();
	ellipse(290, height / 2 + 40, 180, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link spin attack & Ganon stand sprite initialization 
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	image(linkSpinAttack2, 180, 230, linkSpin2HEIGHT, linkSpin2WIDTH);

}
// Link sword swipe animation 1 
function swordSwipeANI1() {
	
	backgroundTemplate();
	// Link dialogue 
	strokeWeight(5);
	textSize(35);
	fill(255);
	text("HIYAH!", 60, height - 160);
	
	// Link icon dimensions
	linkCloseUpWIDTH = linkCloseUp.width * 0.35
	linkCloseUpAR = linkCloseUp.width / linkCloseUp.height
	linkCloseUpHEIGHT = linkCloseUpWIDTH * linkCloseUpAR
	
	// Link icon initialization 
	image(linkCloseUp, 430, 380, linkCloseUpWIDTH, linkCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(430, 380, 135, 140);
	
	// Character shadows 
	fill(0, 0, 0, 125);
	noStroke();
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link jump and Ganon standing sprite initialiation 
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	image(linkJump, 170, 80);
	
}
// Link sword wipe animation 2 
function swordSwipeANI2() {
	
	backgroundTemplate();
	// Link dialogue 
	linkswipe.play();
	strokeWeight(5);
	textSize(35);
	fill(255);
	text("HIYAH!", 60, height - 160);
	
	// Link icon dimensions 
	linkCloseUpWIDTH = linkCloseUp.width * 0.35
	linkCloseUpAR = linkCloseUp.width / linkCloseUp.height
	linkCloseUpHEIGHT = linkCloseUpWIDTH * linkCloseUpAR
	
	// Link icon initialization 
	image(linkCloseUp, 430, 380, linkCloseUpWIDTH, linkCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(430, 380, 135, 140);
	
	// Link swipe sprite dimensions 
	linkSwipeWIDTH = linkSwipe.width * 0.21
	linkSwipeAR = linkSwipe.width / linkSwipe.height
	linkSwipeHEIGHT = linkSwipeWIDTH * linkSwipeAR
	
	// Sprite shadows  
	fill(0, 0, 0, 125);
	noStroke();
	ellipse(380, height / 2 + 40, 180, 15);
	ellipse(480, height / 2 + 40, 180, 15);

	// Link swipe and Ganon standing sprite initialization 
	image(linkSwipe, 300, 180, linkSwipeHEIGHT, linkSwipeWIDTH);
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	
	// Ganon HP loss 
	GanonHP -= attackRnd + 4;
	GanonStatHP -= attackRnd + 4;
}

// Link sword swipe animation 3 
function swordSwipeANI3() {

	backgroundTemplate();
	// Link dialogue 
	strokeWeight(5);
	textSize(35);
	fill(255);
	text("HIYAH!", 60, height - 160);
	
	// Link icon dimensions 
	linkCloseUpWIDTH = linkCloseUp.width * 0.35
	linkCloseUpAR = linkCloseUp.width / linkCloseUp.height
	linkCloseUpHEIGHT = linkCloseUpWIDTH * linkCloseUpAR
		
	// Link icon initialization 
	image(linkCloseUp, 430, 380, linkCloseUpWIDTH, linkCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(430, 380, 135, 140);
	
	// Sprite shadows 
	fill(0, 0, 0, 125);
	noStroke();
	ellipse(80, height / 2 + 25, 90, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link and Ganon stand sprite initialization 
	image(linkStand, 40, height / 3, linkStandWIDTH, linkStandHEIGHT);
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	
}
// Ganon attack 
function ganonAttack1() {
	background("#301934");
	noStroke();
	
	fill("#567d46");
	rect(0, height / 2, width, height / 2);

	stroke(0);
	strokeWeight(10);
	fill("BROWN");
	rect(25, height - 225, width - 50, 150);
	
	// Ganon dialogue design
	strokeWeight(5);
	textSize(35);
	fill("PURPLE");
	text(ganonText[rndTextValue], 50, height - 160);
		
	// Ganon icon dimensions 
	ganonCloseUpWIDTH = ganonCloseUp.width * 0.9
	ganonCloseUpAR = ganonCloseUp.width / ganonCloseUp.height
	ganonCloseUpHEIGHT = ganonCloseUpWIDTH * ganonCloseUpAR
	
	// Ganon icon initialization 
	image(ganonCloseUp, 430, 380, ganonCloseUpWIDTH, ganonCloseUpHEIGHT + 10);
	strokeWeight(10);
	noFill();
	rect(430, 380, 135, 140);
		
	// Sprite shadow 
	noStroke();
	fill(0, 0, 0, 125);
	ellipse(80, height / 2 + 25, 90, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link and Ganon standing sprite initialization 
	image(linkStand, 40, height / 3, linkStandWIDTH, linkStandHEIGHT);
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
		
	
}
// Phantom Ganon attack 
function ganonAttack2() {
	// Background colour change 
	background("#301934");
	noStroke();
	
	fill("#567d46");
	rect(0, height / 2, width, height / 2);

	stroke(0);
	strokeWeight(10);
	fill("BROWN");
	rect(25, height - 225, width - 50, 150);
	
	// Ganon dialogue 
	strokeWeight(5);
	textSize(35);
	fill("PURPLE");
	text(ganonText[rndTextValue], 50, height - 160);
	
	// Ganon icon dimensions 
	ganonCloseUpWIDTH = ganonCloseUp.width * 0.9
	ganonCloseUpAR = ganonCloseUp.width / ganonCloseUp.height
	ganonCloseUpHEIGHT = ganonCloseUpWIDTH * ganonCloseUpAR
	
	// Ganon icon initialization 
	image(ganonCloseUp, 430, 380, ganonCloseUpWIDTH, ganonCloseUpHEIGHT + 10);
	strokeWeight(10);
	noFill();
	rect(430, 380, 135, 140);
	
	// Thunder effect dimensions
	thunderWIDTH = thunder.width * 0.2;
	thunderAR = thunder.width / thunder.height;
	thunderHEIGHT = thunderWIDTH * thunderAR
	
	// Thunder effect initialization 
	image(thunder, -150, -285, thunderWIDTH, thunderHEIGHT);
	
	noStroke();
	fill(0, 0, 0, 125);
	ellipse(80, height / 2 + 25, 90, 15);
	
	if (GanonAttackRND > 2) {
	// Ganon attack sprite dimensions 
	ganonAttackWIDTH = ganonAttack.width * 0.3
	ganonAttackAR = ganonAttack.width / ganonAttack.height
	ganonAttackHEIGHT = ganonAttackWIDTH * ganonAttackAR
	// Ganon attack sprite initialization 
	image(ganonAttack, -30, -10, ganonAttackHEIGHT, ganonAttackWIDTH);
	}
	
	if (GanonAttackRND < 2) {
	// Phantom Ganon audio 
	phantomganonaudio.play();
		
	// Phantom Ganon sprite dimensions 
	phantomGanonWIDTH = phantomGanon.width * 0.12
	phantomGanonAR = phantomGanon.width / phantomGanon.height
	phantomGanonHEIGHT = phantomGanonWIDTH * phantomGanonAR
		
	// Phantom Ganon sprite initialization 
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	image(phantomGanon, 150, 0, phantomGanonHEIGHT, phantomGanonWIDTH);
	} // Link dodge feature & design 
	if (linkDodgeRND > 3) {
	linkdodge.play();
	strokeWeight(8);
	stroke(0);
	fill(200);
	textSize(20);
	// Dodge text
	text("*Dodge*", 140, 280); 
	// Link dodge sprite dimensions 
	linkDodgeWIDTH = linkDodge.width * 0.57
	linkDodgeAR = linkDodge.width / linkDodge.height
	linkDodgeHEIGHT = linkDodgeWIDTH * linkDodgeAR
	// Link dodge sprite initialization 
	image(linkDodge, -50, 180, linkDodgeHEIGHT, linkDodgeWIDTH);

	} if (linkDodgeRND < 3) {
	// Link hurt feature 
	linkhurt.play();
	// Link hurt sprite dimensions 
	linkHurtWIDTH = linkHurt.width * 0.28
	linkHurtAR = linkHurt.width / linkHurt.height
	linkHurtHEIGHT = linkHurtWIDTH * linkHurtAR
		// Link hurt sprite initialization 
		image(linkHurt, 30, 196, linkHurtHEIGHT + 10, linkHurtWIDTH);
			LinkHP -= (attackRnd - floor(random(0, 6)));
		
	}
}
// Static attack screen 
function staticAttackScreen() {
	background("#0c1445");
	noStroke();
	fill("#567d46");
	rect(0, height / 2, width, height / 2);
	// Link standing sprite dimensions 
		linkStandWIDTH = linkStand.width * 0.15
	linkStandAR = linkStand.width / linkStand.height
	linkStandHEIGHT = linkStandWIDTH * linkStandAR
	// Ganon standing sprite dimensions 
	ganonStandWIDTH = ganonStand.width * 0.10
	ganonStandAR = ganonStand.width / ganonStand.height
	ganonStandHEIGHT = ganonStandWIDTH * ganonStandAR

	noStroke();
	fill(0, 0, 0, 125);
	ellipse(80, height / 2 + 25, 90, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link & Ganon character sprite initialization
	image(linkStand, 40, height / 3, linkStandWIDTH, linkStandHEIGHT);
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	
}

function HUD() {

	// Link icon dimensions 
	linkCloseUpWIDTH = linkCloseUp.width * 0.15
	linkCloseUpAR = linkCloseUp.width / linkCloseUp.height
	linkCloseUpHEIGHT = linkCloseUpWIDTH * linkCloseUpAR
	
	// Ganon icon dimensions 
	ganonCloseUpWIDTH = ganonCloseUp.width * 0.4
	ganonCloseUpAR = ganonCloseUp.width / ganonCloseUp.height
	ganonCloseUpHEIGHT = ganonCloseUpWIDTH * ganonCloseUpAR
	
	// Link HP gauge status colours 
	if (LinkHP > 50) {
		LinkHPGauge = "GREEN";
	}
	if (LinkHP < 50 && LinkHP > 25) {
		LinkHPGauge = "YELLOW";
	}
	if (LinkHP < 25) {
		LinkHPGauge = "RED";
	}
	
	stroke(0);
	strokeWeight(5);
	fill(LinkHPGauge);
	rect(60, 0, LinkHP * 2, 25);
	
	// Ganon HP gauge status colours 
	if (GanonHP > 100) {
		GanonHPGauge = "GREEN";
	}
	if (GanonHP < 100 && GanonHP > 50) {
		GanonHPGauge = "Yellow";
	}
	if (GanonHP < 50) {
		GanonHPGauge = "RED";
	}
	GanonStatHP = map(GanonHP, 0, 200, 0, -100);
	fill(GanonHPGauge);
	stroke(0);
	strokeWeight(5);
	rect(540, 0, GanonStatHP * 2, 25);
	
	// Link & Ganon icon initialization 
	image(linkCloseUp, 0, 0, linkCloseUpWIDTH, linkCloseUpHEIGHT);
	image(ganonCloseUp, 540, 5, ganonCloseUpWIDTH, ganonCloseUpHEIGHT);

	stroke(0);
	strokeWeight(5);
	noFill();
	rect(540, 0, 60, 60);
	rect(0, 0, 60, 60);
			
	strokeWeight(5);
	rect(340, 0, 200, 25);
	

	strokeWeight(5);
	rect(60, 0, 200, 25);
	
	// Link & Ganon name text 
	strokeWeight(2);
	stroke(150);
	fill(0);
	textSize(25);
	text("Ganon", 455, 50);
	text("Link", 70, 50);
			

}

// Escape failure feature 
function failureScreen() {
	escapetimer++;
	
	
	if (escapetimer === 1) {
	
	screen[2] = false;
	
	backgroundTemplate();
	
	//Button function call
	buttons(s3buttonX[0], height / 1.35);
	buttons(s3buttonX[1], height / 1.35);
	buttons(s3buttonX[2], height / 1.35);
	
//Button text
	fill(0);
	strokeWeight(1);
	textSize(25);
	text("FIGHT", 261, height / 1.33);
	text("STATS", 80, height / 1.33);
	text("RUN", 453, height / 1.33);

	// Sprite shadow 
	noStroke();
	fill(0, 0, 0, 125);
	ellipse(80, height / 2 + 25, 90, 15);
	ellipse(480, height / 2 + 40, 180, 15);
	
	// Link stand and Ganon stand sprite initialization 
	image(linkStand, 40, height / 3, linkStandWIDTH, linkStandHEIGHT);
	image(ganonStand, 400, height / 4, ganonStandWIDTH, ganonStandHEIGHT);
	
	fill(0, 0, 0, 100);
	rect(0, 0, WIDTH, HEIGHT);
	
	stroke(0);
	strokeWeight(5);
	fill(120);
	rect(100, 250, 400, 150);
	
	// Special escape fail dialogue 
	textSize(28);
	fill("PURPLE");
	text("You Can't Run Boy!", 120, 300);
	
	// Ganon icon dimensions 
	ganonCloseUpWIDTH = ganonCloseUp.width * 0.8
	ganonCloseUpAR = ganonCloseUp.width / ganonCloseUp.height
	ganonCloseUpHEIGHT = ganonCloseUpWIDTH * ganonCloseUpAR
	
	// Ganon icon initialization 
	image(ganonCloseUp, 380, 254, ganonCloseUpWIDTH, ganonCloseUpHEIGHT);
	strokeWeight(10);
	noFill();
	rect(380, 254, 115, 115);
		
	HUD();	
		
	}
	// Fled screen end
	if (escapetimer === 15) {
		fled = false;
		screen[2] = true;
		escapetimer = 0;
	}
}
// Defeat feature 
function defeat() {
	linkhurt.play();
	musicmez.stop();
	background(0);
	
	// Defeat screen sprite 
	defeatW = defeatscreen.width * 0.35;
	defeatAR = defeatscreen.width / defeatscreen.height;
	defeatH = defeatW / defeatAR;
	
	// Defeat screen initialization 
	image(defeatscreen, 5, 5, defeatW, defeatH);
	
	// Defeat text 
	textSize(50);
	strokeWeight(5);
	fill("RED");
	text("DEFEAT", 100, 200);
}

// Victory feature 
function victory() {
	linkswipe.play();
	musicmez.stop();
	background(0);
	
	// Victory screen dimensions 
	winW = victoryscreen.width * 0.3;
	winAR = victoryscreen.width / victoryscreen.height;
	winH = winW / winAR
	
	// Victory screen initialization 
	image(victoryscreen, 0, 300, winW, winH);
	
	// Victory text 
	textSize(50);
	strokeWeight(5);
	fill("GREEN");
	text("VICTORY", 100, 200);
	
}